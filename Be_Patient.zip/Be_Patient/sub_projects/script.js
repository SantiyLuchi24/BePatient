// Obtener elementos del DOM
const loadingBar = document.getElementById('loadingBar');
const loadingProgress = document.createElement('div'); // Se crea el elemento para la progresión
loadingProgress.classList.add('loading-progress'); // Se añade la clase al elemento

// Variable para el tiempo de carga (en milisegundos)
let loadTime = 60000; // Puedes cambiar el tiempo de carga aquí

// Función para iniciar la carga de la barra
function startLoading() {
    loadingBar.appendChild(loadingProgress); // Se agrega la progresión a la barra
    setTimeout(showPopup, loadTime);
}

// Función para mostrar el popup
function showPopup() {
    trophyPopup.style.display = 'block';
}

// Función para cerrar el popup
function closePopup() {
    trophyPopup.style.display = 'none';
}

// Event listener para iniciar la carga de la barra al pasar el cursor sobre ella
loadingBar.addEventListener('mouseenter', startLoading);

// Event listener para reiniciar la barra cuando el cursor sale de ella
loadingBar.addEventListener('mouseleave', function() {
    loadingBar.removeChild(loadingProgress); // Se remueve la progresión de la barra
});

// Event listener para cerrar el popup al hacer clic en el botón de cerrar (×)
closePopup.addEventListener('click', closePopup);
